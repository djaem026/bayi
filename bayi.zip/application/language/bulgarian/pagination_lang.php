<?php

$lang['first'] = 'Първа';
$lang['last'] = 'Последна';
$lang['next'] = 'Следваща';
$lang['previous'] = 'Предишна';
