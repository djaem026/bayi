﻿var lang = {
    added_to_cart: "Ditambahkan ke keranjang",
    error_to_cart: "Ada masalah dengan sistem keranjang! Coba lagi!",
    no_products: "Tidak ada produk",
    confirm_clear_cart: "Apakah anda yakin ingin menghapus semua barang di keranjang?",
    cleared_cart: "Keranjang anda kosong",
    are_you_sure: "Anda yakin?",
    yes: "Ya",
    no: "Tidak",
    clear_all: "Hapus",
    checkout: "Pembayaran",
    remove_from_cart: "Dihapus dari keranjang",
    enter_valid_email: "Masukan alamat email yang benar",
    discountCodeInvalid: "Kode diskon tidak benar"
};