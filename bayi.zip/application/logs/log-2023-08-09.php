<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-09 06:11:19 --> 404 Page Not Found: /index
ERROR - 2023-08-09 13:54:17 --> 404 Page Not Found: /index
ERROR - 2023-08-09 16:44:17 --> 404 Page Not Found: /index
ERROR - 2023-08-09 17:36:40 --> 404 Page Not Found: /index
ERROR - 2023-08-09 21:16:43 --> 404 Page Not Found: /index
ERROR - 2023-08-09 22:02:20 --> 404 Page Not Found: 
