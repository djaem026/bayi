<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-25 00:48:38 --> 404 Page Not Found: /index
ERROR - 2023-06-25 00:48:45 --> 404 Page Not Found: /index
ERROR - 2023-06-25 00:56:53 --> 404 Page Not Found: /index
ERROR - 2023-06-25 01:36:08 --> 404 Page Not Found: /index
ERROR - 2023-06-25 01:50:33 --> 404 Page Not Found: /index
ERROR - 2023-06-25 02:14:29 --> 404 Page Not Found: /index
ERROR - 2023-06-25 02:47:40 --> 404 Page Not Found: /index
ERROR - 2023-06-25 02:47:40 --> 404 Page Not Found: /index
ERROR - 2023-06-25 11:54:45 --> 404 Page Not Found: /index
ERROR - 2023-06-25 13:48:15 --> 404 Page Not Found: /index
