<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-29 03:53:54 --> 404 Page Not Found: /index
ERROR - 2023-05-29 03:53:54 --> 404 Page Not Found: /index
ERROR - 2023-05-29 03:55:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:55:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:55:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 03:56:03 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 03:56:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 03:56:12 --> 404 Page Not Found: /index
ERROR - 2023-05-29 03:56:12 --> 404 Page Not Found: /index
ERROR - 2023-05-29 03:56:12 --> 404 Page Not Found: /index
ERROR - 2023-05-29 03:56:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:56:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:56:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:57:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 03:57:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 03:57:14 --> 404 Page Not Found: /index
ERROR - 2023-05-29 03:57:14 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:22 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:22 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:23 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:23 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:24 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:24 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:47 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:01:47 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:02:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:02:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:03:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:03:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:03:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:03:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:03:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:03:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:04:06 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 04:04:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:04:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:04:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:04:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:04:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:04:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:05:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 04:05:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:05:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:05:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 04:05:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:05:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:06:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:06:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:07:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:07:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:35:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:35:27 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:35:27 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:35:52 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 04:35:59 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:35:59 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:36:12 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 04:36:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:36:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:36:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 04:36:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:36:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:36:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 04:36:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:36:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:36:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 04:36:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:36:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:36:59 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 04:37:03 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:37:03 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:37:03 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:37:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:30 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\bayi\application\modules\admin\controllers\ecommerce\Orders.php 121
ERROR - 2023-05-29 04:37:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:37:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:37:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:38:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:38:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:38:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:38:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:38:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:38:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:38:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:38:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:38:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:38:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:38:48 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-29 04:38:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:38:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:38:51 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:38:51 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:39:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:39:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:39:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:39:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:39:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:39:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:39:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:39:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:39:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:39:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:39:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:39:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:39:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:39:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:39:45 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:39:45 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:40:09 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:40:09 --> 404 Page Not Found: /index
ERROR - 2023-05-29 04:40:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 04:40:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 04:40:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 19:40:31 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:40:31 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:40:35 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:40:35 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:44:08 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\bayi\application\controllers\Checkout.php 19
ERROR - 2023-05-29 19:45:31 --> Could not find the language line "user_order_history"
ERROR - 2023-05-29 19:45:33 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:45:33 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:45:40 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:45:40 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:45:45 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:45:45 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:46:57 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:46:57 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:47:47 --> Cant save order!! 
ERROR - 2023-05-29 19:47:49 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:47:49 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:47:50 --> Cant save order!! 
ERROR - 2023-05-29 19:50:18 --> Could not find the language line "user_order_history"
ERROR - 2023-05-29 19:50:20 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:50:20 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:51:03 --> Severity: error --> Exception: Call to undefined method Checkout::login_check() C:\xampp\htdocs\bayi\application\controllers\Checkout.php 18
ERROR - 2023-05-29 19:51:04 --> Severity: error --> Exception: Call to undefined method Checkout::login_check() C:\xampp\htdocs\bayi\application\controllers\Checkout.php 18
ERROR - 2023-05-29 19:51:52 --> Severity: error --> Exception: Call to undefined method Checkout::login_check() C:\xampp\htdocs\bayi\application\controllers\Checkout.php 18
ERROR - 2023-05-29 19:52:33 --> Could not find the language line "user_order_history"
ERROR - 2023-05-29 19:52:35 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:52:35 --> 404 Page Not Found: /index
ERROR - 2023-05-29 19:52:36 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\bayi\application\controllers\Checkout.php 19
ERROR - 2023-05-29 19:53:14 --> Could not find the language line "user_order_history"
ERROR - 2023-05-29 19:55:27 --> Severity: Notice --> Undefined variable: userInfo C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 19:55:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 19:55:34 --> Severity: Notice --> Undefined variable: userInfo C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 19:55:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 19:55:50 --> Severity: Notice --> Undefined variable: userInfo C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 19:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 19:55:51 --> Severity: Notice --> Undefined variable: userInfo C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 19:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 60
ERROR - 2023-05-29 20:01:24 --> Query error: Unknown column 'shippingAmount' in 'where clause' - Invalid query: SELECT value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:01:54 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT `shippingAmount` as value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:01:55 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT `shippingAmount` as value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:01:55 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT `shippingAmount` as value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:01:55 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT `shippingAmount` as value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:01:55 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT `shippingAmount` as value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:01:55 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT `shippingAmount` as value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:01:56 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT `shippingAmount` as value FROM value_store WHERE shippingAmount != 0 LIMIT 1
ERROR - 2023-05-29 20:02:55 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT shippingAmount as shipping FROM `value_store` WHERE shippingAmount != 0
ERROR - 2023-05-29 20:02:56 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT shippingAmount as shipping FROM `value_store` WHERE shippingAmount != 0
ERROR - 2023-05-29 20:02:56 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT shippingAmount as shipping FROM `value_store` WHERE shippingAmount != 0
ERROR - 2023-05-29 20:02:56 --> Query error: Unknown column 'shippingAmount' in 'field list' - Invalid query: SELECT shippingAmount as shipping FROM `value_store` WHERE shippingAmount != 0
ERROR - 2023-05-29 20:03:22 --> Severity: error --> Exception: Call to undefined method Home_admin_model::getShipping() C:\xampp\htdocs\bayi\application\controllers\Checkout.php 58
ERROR - 2023-05-29 20:03:34 --> 404 Page Not Found: /index
ERROR - 2023-05-29 20:03:34 --> 404 Page Not Found: /index
ERROR - 2023-05-29 20:09:09 --> 404 Page Not Found: /index
ERROR - 2023-05-29 20:09:09 --> 404 Page Not Found: /index
ERROR - 2023-05-29 20:17:27 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 20:19:11 --> Severity: Notice --> Undefined index: product_price C:\xampp\htdocs\bayi\application\views\templates\greenlabel\user.php 59
ERROR - 2023-05-29 20:19:21 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\bayi\application\views\templates\greenlabel\user.php 59
ERROR - 2023-05-29 20:25:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:25:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:25:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:25:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:25:31 --> Severity: Notice --> Undefined index: last_login C:\xampp\htdocs\bayi\application\modules\admin\views\home\home.php 26
ERROR - 2023-05-29 20:25:31 --> Severity: Notice --> Undefined index: last_login C:\xampp\htdocs\bayi\application\modules\admin\views\home\home.php 27
ERROR - 2023-05-29 20:26:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:26:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:26:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:26:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:26:47 --> 404 Page Not Found: /index
ERROR - 2023-05-29 20:26:47 --> 404 Page Not Found: /index
ERROR - 2023-05-29 20:26:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:26:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:26:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:26:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:26:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:26:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:27:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:27:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:28:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:28:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:30:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:30:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:30:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:30:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:31:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:31:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:31:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:31:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:34:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:34:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:35:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:35:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:35:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:35:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:35:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:35:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:36:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:36:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:36:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:36:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:36:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:36:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:36:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:36:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:36:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:36:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:36:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:36:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:37:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:37:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 20:38:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-29 20:38:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-29 23:36:20 --> 404 Page Not Found: /index
ERROR - 2023-05-29 23:36:20 --> 404 Page Not Found: /index
ERROR - 2023-05-29 23:42:34 --> 404 Page Not Found: Checkout/samplemail
ERROR - 2023-05-29 23:42:51 --> 404 Page Not Found: /index
ERROR - 2023-05-29 23:42:55 --> 404 Page Not Found: Checkout/samplemail
ERROR - 2023-05-29 23:43:44 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-29 23:44:04 --> 404 Page Not Found: Checkout/setActivationLink
ERROR - 2023-05-29 23:45:02 --> 404 Page Not Found: /index
ERROR - 2023-05-29 23:46:46 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:47:02 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:48:45 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:53:25 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:53:25 --> Severity: error --> Exception: Call to undefined method SendMail::send() /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 42
ERROR - 2023-05-29 23:54:00 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:54:00 --> Severity: Notice --> Undefined property: CI::$mail /home/u299472748/domains/bayi.space/public_html/application/third_party/MX/Controller.php 59
ERROR - 2023-05-29 23:54:00 --> Severity: error --> Exception: Call to a member function send() on null /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 42
ERROR - 2023-05-29 23:54:30 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:54:30 --> Severity: error --> Exception: Call to undefined method Users::sendmail() /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 42
ERROR - 2023-05-29 23:55:03 --> Severity: error --> Exception: Call to undefined method CI_Email::sendTo() /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 41
ERROR - 2023-05-29 23:55:55 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:56:52 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:56:52 --> Severity: Notice --> Undefined property: CI::$sendMail /home/u299472748/domains/bayi.space/public_html/application/third_party/MX/Controller.php 59
ERROR - 2023-05-29 23:56:52 --> Severity: error --> Exception: Call to a member function send() on null /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 72
ERROR - 2023-05-29 23:57:14 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:57:14 --> Severity: error --> Exception: Call to undefined method SendMail::send() /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 72
ERROR - 2023-05-29 23:57:25 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:57:25 --> Severity: error --> Exception: Call to undefined method Checkout::sendmail() /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 72
ERROR - 2023-05-29 23:57:25 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:57:25 --> Severity: error --> Exception: Call to undefined method Checkout::sendmail() /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 72
ERROR - 2023-05-29 23:57:26 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:57:26 --> Severity: error --> Exception: Call to undefined method Checkout::sendmail() /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 72
ERROR - 2023-05-29 23:57:26 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-29 23:57:26 --> Severity: error --> Exception: Call to undefined method Checkout::sendmail() /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 72
