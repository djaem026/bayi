<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-30 01:21:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:21:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:22:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:22:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:23:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:23:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:23:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:23:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:23:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:23:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:23:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:23:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:23:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:23:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:24:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:24:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:26:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:26:13 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:26:14 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:02:21 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:03:13 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:03:53 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:04:05 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:04:06 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:04:07 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:04:27 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:05:28 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:05:57 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:05:59 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:06:19 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:06:19 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:06:20 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:06:21 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:06:22 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:06:22 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:06:24 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-30 00:07:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:07:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:12:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:12:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:18:51 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-30 00:19:00 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-30 00:22:19 --> 404 Page Not Found: Checkout/doEmail
ERROR - 2023-05-30 00:25:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:25:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:26:01 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:26:01 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:28:03 --> Severity: Notice --> Undefined property: SendMail::$load /home/u299472748/domains/bayi.space/public_html/application/libraries/SendMail.php 57
ERROR - 2023-05-30 00:28:03 --> Severity: error --> Exception: Call to a member function library() on null /home/u299472748/domains/bayi.space/public_html/application/libraries/SendMail.php 57
ERROR - 2023-05-30 00:28:33 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:29:18 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-30 00:29:35 --> Severity: Notice --> Undefined property: SendMail::$email /home/u299472748/domains/bayi.space/public_html/application/libraries/SendMail.php 60
ERROR - 2023-05-30 00:29:35 --> Severity: error --> Exception: Call to a member function initialize() on null /home/u299472748/domains/bayi.space/public_html/application/libraries/SendMail.php 60
ERROR - 2023-05-30 00:30:11 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:30:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:30:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:30:17 --> Severity: Notice --> Undefined property: SendMail::$email /home/u299472748/domains/bayi.space/public_html/application/libraries/SendMail.php 60
ERROR - 2023-05-30 00:30:17 --> Severity: error --> Exception: Call to a member function initialize() on null /home/u299472748/domains/bayi.space/public_html/application/libraries/SendMail.php 60
ERROR - 2023-05-30 00:30:36 --> Severity: error --> Exception: Call to undefined method SendMail::library() /home/u299472748/domains/bayi.space/public_html/application/libraries/SendMail.php 57
ERROR - 2023-05-30 00:31:55 --> Severity: Notice --> Undefined variable: to /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 269
ERROR - 2023-05-30 00:31:55 --> Severity: Notice --> Undefined variable: sub /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 270
ERROR - 2023-05-30 00:34:22 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:34:22 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:38:18 --> 404 Page Not Found: Checkout/doEmail
ERROR - 2023-05-30 00:40:16 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:40:16 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:40:20 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-30 00:40:46 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-30 00:41:04 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:41:04 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:41:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:41:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:41:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:41:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:41:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:41:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:41:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:41:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:41:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:41:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:42:01 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:42:01 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:42:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:42:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:42:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:42:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:42:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:42:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:42:28 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-30 00:42:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:42:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:42:36 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:42:36 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:42:42 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-30 00:43:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:43:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:43:52 --> Severity: Notice --> Undefined index: logged_in /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 20
ERROR - 2023-05-30 00:45:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:45:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:45:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:45:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:46:53 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:46:53 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:47:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:47:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:47:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:47:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:47:58 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:48:02 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:48:02 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:48:04 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:48:44 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:48:54 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:49:13 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:49:25 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:49:38 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:49:40 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Checkout.php 62
ERROR - 2023-05-30 00:51:22 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:51:22 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:51:43 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:51:43 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:51:54 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:51:54 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:31 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:33 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:33 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:33 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:52:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:53:24 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:53:24 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:53:33 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:53:33 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:58:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:58:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:59:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 00:59:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 00:59:38 --> 404 Page Not Found: /index
ERROR - 2023-05-30 00:59:38 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:00:25 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:00:25 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:31:44 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:31:44 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:42:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:42:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:42:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:42:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:43:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:43:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:43:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:43:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:43:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:43:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:43:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:43:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:43:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:43:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:44:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:44:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:44:21 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:44:21 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:44:38 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:44:38 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:47:37 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:47:37 --> 404 Page Not Found: /index
ERROR - 2023-05-30 01:54:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:54:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:54:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:54:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:55:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:55:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:56:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:56:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 01:56:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 01:56:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:01:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:01:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:01:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:01:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:02:20 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:02:20 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:02:20 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:02:25 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-30 02:02:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:02:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:03:39 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:03:39 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:04:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:04:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:05:52 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:07:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:07:47 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:11:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:11:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:14:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:14:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:21 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:21 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:28 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:28 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:34 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:34 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:47 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:17:47 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:18:00 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:18:00 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:18:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:18:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:18:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:18:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:18:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:18:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:18:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:18:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:18:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:18:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:18:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:18:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:19:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:19:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:19:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:19:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:19:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:19:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:19:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:19:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:19:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:19:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:19:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:19:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 02:28:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:28:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:28:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:28:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:35:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:35:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 02:55:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 02:55:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:00:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:00:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:02:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:02:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:03:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:03:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:04:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:04:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:04:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:04:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:04:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:04:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:04:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:04:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:05:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:05:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:05:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:05:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:05:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:05:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:05:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:05:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:06:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:06:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:06:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:06:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:06:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:06:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:06:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:06:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:06:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:06:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:06:57 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:06:57 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:00 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:00 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:03 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:03 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:05 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:05 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:09 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:09 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:12 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:25 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:25 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:31 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:31 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:39 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:39 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:46 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:46 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:48 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:48 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:52 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:52 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:07:55 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:16:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:16:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:16:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:16:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:17:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:17:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:19:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:19:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:19:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:19:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:20:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:20:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:20:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:20:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:20:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:20:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:24:13 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:24:13 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:25:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:25:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:25:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:25:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:25:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:25:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:25:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:25:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:27:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:27:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:09 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2023-05-30 03:28:12 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2023-05-30 03:28:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:30 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:28:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:28:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:28:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:28:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:28:46 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:28:57 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:28:58 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:29:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:05 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:29:05 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:29:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:30 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:29:30 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:29:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:29:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:29:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:35:09 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:35:09 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:40:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:40:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:40:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:40:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:41:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:41:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:41:45 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:41:45 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:43:53 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:43:53 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:48:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:48:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:50:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:50:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:51:08 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:51:08 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:52:11 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:52:11 --> 404 Page Not Found: /index
ERROR - 2023-05-30 03:52:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:52:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:52:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:52:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:54:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:54:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:55:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:55:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:56:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:56:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:57:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:57:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:58:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:58:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 03:59:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 03:59:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:02:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:02:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:02:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:02:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:02:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:02:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:02:32 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:02:32 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:02:32 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:02:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:02:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:02:35 --> Severity: Notice --> Undefined variable: class /home/u299472748/domains/bayi.space/public_html/application/modules/admin/views/ecommerce/orders.php 80
ERROR - 2023-05-30 04:02:35 --> Severity: Notice --> Undefined variable: type /home/u299472748/domains/bayi.space/public_html/application/modules/admin/views/ecommerce/orders.php 90
ERROR - 2023-05-30 04:03:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:03:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:05:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:05:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:05:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:05:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:05:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:05:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:05:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:16:00 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:16:00 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:16:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:16:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:21:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:21:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:21:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:21:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:21:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:21:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:21:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:21:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:21:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:21:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:21:48 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:21:48 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:21:48 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:21:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:21:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:22:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:22:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:22:21 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-30 04:22:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:22:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:22:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:22:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:22:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 04:22:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 04:34:13 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:34:19 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:34:19 --> 404 Page Not Found: /index
ERROR - 2023-05-30 04:36:20 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:42:06 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:42:06 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:42:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:42:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:42:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:42:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:42:49 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:42:49 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:43:10 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:43:10 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:44:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:44:35 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:44:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:44:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:44:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:44:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:45:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:45:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:46:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:46:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:47:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:47:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:47:48 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:47:48 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:48:13 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:48:13 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:48:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:48:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:49:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:49:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:49:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:49:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:49:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:49:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:50:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 05:50:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 05:52:31 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:52:31 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:54:19 --> 404 Page Not Found: /index
ERROR - 2023-05-30 05:54:19 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:01:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:01:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:02:07 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:02:07 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:02:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:02:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:02:47 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:02:47 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:02:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:02:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:03:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:03:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:03:36 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:03:36 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:04:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:04:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:04:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:04:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:04:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:04:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:04:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:04:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:04:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:04:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:05:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:05:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:05:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:05:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:05:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:05:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:06:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:06:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:06:32 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:06:32 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:06:34 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:06:34 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:06:45 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:06:45 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:09:43 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:09:43 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:17:28 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:17:34 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:17:34 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:19:41 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:26:37 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:26:40 --> 404 Page Not Found: /index
ERROR - 2023-05-30 06:51:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:51:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:51:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:51:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:51:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:51:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:52:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:52:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:53:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:53:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 06:53:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 06:53:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:04:28 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:13:27 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:13:27 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:13:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:13:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:14:03 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:14:03 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:14:15 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:14:15 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:14:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:14:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:15:01 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:15:01 --> 404 Page Not Found: /index
ERROR - 2023-05-30 07:17:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:17:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:17:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:17:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:17:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:17:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:17:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:17:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:21:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:21:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:21:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:21:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:24:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:24:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:24:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:24:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 07:24:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 07:24:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 08:35:46 --> 404 Page Not Found: /index
ERROR - 2023-05-30 08:35:46 --> 404 Page Not Found: /index
ERROR - 2023-05-30 09:30:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 09:30:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 09:31:07 --> 404 Page Not Found: /index
ERROR - 2023-05-30 09:31:07 --> 404 Page Not Found: /index
ERROR - 2023-05-30 09:47:52 --> 404 Page Not Found: /index
ERROR - 2023-05-30 09:47:52 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:02:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:02:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:02:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:02:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:03:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:03:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:03:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:03:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:03:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:03:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:03:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:03:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:03:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:03:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:05:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:05:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:06:45 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:06:45 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:09:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:09:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:10:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:10:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:10:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:10:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:10:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:10:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:11:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:11:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:11:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:11:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:11:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:11:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:11:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:11:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:12:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:12:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:12:42 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-30 10:12:48 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-30 10:13:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:13:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:13:37 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:13:37 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:14:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:14:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:17:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:17:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:17:56 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:17:56 --> 404 Page Not Found: /index
ERROR - 2023-05-30 10:19:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:19:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:19:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:19:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:19:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:19:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:19:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:19:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:33:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:33:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:33:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:33:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:33:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:33:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:34:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:34:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:34:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:34:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:35:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:35:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:35:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:35:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:35:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:35:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:36:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:36:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:36:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:36:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:36:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:36:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:37:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:37:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:40:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:40:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 10:41:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-30 10:41:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-30 12:24:24 --> 404 Page Not Found: /index
ERROR - 2023-05-30 12:24:24 --> 404 Page Not Found: /index
ERROR - 2023-05-30 12:24:51 --> 404 Page Not Found: /index
ERROR - 2023-05-30 12:24:51 --> 404 Page Not Found: /index
ERROR - 2023-05-30 12:29:44 --> 404 Page Not Found: /index
ERROR - 2023-05-30 13:52:23 --> 404 Page Not Found: /index
ERROR - 2023-05-30 13:52:24 --> 404 Page Not Found: /index
ERROR - 2023-05-30 13:52:25 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:00:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:00:50 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:09:20 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:09:21 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:09:21 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:10:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:10:18 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:11:26 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:11:26 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:20:36 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:20:36 --> 404 Page Not Found: /index
ERROR - 2023-05-30 14:20:36 --> 404 Page Not Found: /index
ERROR - 2023-05-30 15:38:46 --> 404 Page Not Found: /index
ERROR - 2023-05-30 15:38:46 --> 404 Page Not Found: /index
ERROR - 2023-05-30 15:38:49 --> 404 Page Not Found: /index
ERROR - 2023-05-30 15:39:03 --> 404 Page Not Found: /index
ERROR - 2023-05-30 15:39:03 --> 404 Page Not Found: /index
ERROR - 2023-05-30 15:39:07 --> 404 Page Not Found: /index
ERROR - 2023-05-30 17:30:59 --> 404 Page Not Found: /index
ERROR - 2023-05-30 17:30:59 --> 404 Page Not Found: /index
ERROR - 2023-05-30 21:48:04 --> 404 Page Not Found: /index
ERROR - 2023-05-30 21:48:10 --> 404 Page Not Found: /index
ERROR - 2023-05-30 21:48:10 --> 404 Page Not Found: /index
ERROR - 2023-05-30 21:49:42 --> 404 Page Not Found: /index
ERROR - 2023-05-30 21:52:14 --> 404 Page Not Found: /index
ERROR - 2023-05-30 21:52:16 --> 404 Page Not Found: /index
ERROR - 2023-05-30 23:14:06 --> 404 Page Not Found: /index
ERROR - 2023-05-30 23:14:06 --> 404 Page Not Found: /index
ERROR - 2023-05-30 23:44:01 --> 404 Page Not Found: /index
