<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-05 15:55:36 --> 404 Page Not Found: /index
ERROR - 2023-07-05 16:07:09 --> 404 Page Not Found: /index
ERROR - 2023-07-05 16:32:08 --> 404 Page Not Found: /index
