<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-19 05:48:51 --> 404 Page Not Found: /index
ERROR - 2023-06-19 06:26:32 --> 404 Page Not Found: /index
ERROR - 2023-06-19 06:42:12 --> 404 Page Not Found: /index
ERROR - 2023-06-19 06:54:26 --> 404 Page Not Found: /index
ERROR - 2023-06-19 07:12:06 --> 404 Page Not Found: /index
ERROR - 2023-06-19 07:51:10 --> 404 Page Not Found: 
ERROR - 2023-06-19 13:37:37 --> 404 Page Not Found: /index
ERROR - 2023-06-19 13:37:43 --> 404 Page Not Found: /index
ERROR - 2023-06-19 13:37:44 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2023-06-19 13:37:45 --> 404 Page Not Found: /index
