<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-05 08:15:48 --> 404 Page Not Found: /index
ERROR - 2023-09-05 20:24:21 --> 404 Page Not Found: /index
