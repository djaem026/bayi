<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-22 04:20:08 --> 404 Page Not Found: /index
ERROR - 2023-08-22 12:32:01 --> 404 Page Not Found: /index
ERROR - 2023-08-22 13:58:16 --> 404 Page Not Found: /index
ERROR - 2023-08-22 20:40:17 --> 404 Page Not Found: /index
ERROR - 2023-08-22 22:28:28 --> 404 Page Not Found: /index
