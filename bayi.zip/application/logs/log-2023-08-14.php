<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-14 07:18:40 --> 404 Page Not Found: /index
ERROR - 2023-08-14 09:28:34 --> 404 Page Not Found: /index
ERROR - 2023-08-14 09:28:34 --> 404 Page Not Found: /index
ERROR - 2023-08-14 09:28:34 --> 404 Page Not Found: /index
ERROR - 2023-08-14 09:28:35 --> 404 Page Not Found: /index
ERROR - 2023-08-14 10:23:17 --> 404 Page Not Found: /index
ERROR - 2023-08-14 19:49:14 --> 404 Page Not Found: /index
