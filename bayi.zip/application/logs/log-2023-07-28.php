<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-28 02:18:27 --> 404 Page Not Found: /index
ERROR - 2023-07-28 13:58:37 --> 404 Page Not Found: /index
ERROR - 2023-07-28 23:59:16 --> 404 Page Not Found: /index
ERROR - 2023-07-28 23:59:16 --> 404 Page Not Found: /index
