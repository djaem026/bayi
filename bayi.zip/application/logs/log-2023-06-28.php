<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-28 02:03:47 --> 404 Page Not Found: /index
ERROR - 2023-06-28 08:25:57 --> 404 Page Not Found: /index
ERROR - 2023-06-28 08:30:38 --> 404 Page Not Found: /index
ERROR - 2023-06-28 08:58:36 --> 404 Page Not Found: /index
ERROR - 2023-06-28 09:02:22 --> 404 Page Not Found: /index
ERROR - 2023-06-28 09:16:39 --> 404 Page Not Found: /index
ERROR - 2023-06-28 09:21:20 --> 404 Page Not Found: /index
ERROR - 2023-06-28 13:12:32 --> 404 Page Not Found: /index
ERROR - 2023-06-28 15:38:29 --> 404 Page Not Found: /index
ERROR - 2023-06-28 20:51:59 --> 404 Page Not Found: /index
ERROR - 2023-06-28 20:52:24 --> 404 Page Not Found: /index
ERROR - 2023-06-28 20:52:25 --> 404 Page Not Found: /index
ERROR - 2023-06-28 23:34:27 --> 404 Page Not Found: /index
