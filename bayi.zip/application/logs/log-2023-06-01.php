<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-01 00:48:02 --> 404 Page Not Found: /index
ERROR - 2023-06-01 00:48:02 --> 404 Page Not Found: /index
ERROR - 2023-06-01 00:53:35 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 00:53:35 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:03:35 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:03:35 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:15:50 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:16:25 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:16:25 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:17:01 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:17:01 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:17:09 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:17:09 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:17:13 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:17:13 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:17:24 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:17:24 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:18:25 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:18:26 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:18:26 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:18:29 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:18:29 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:18:39 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:18:39 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:18:39 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:18:45 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:18:45 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:19:47 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:19:47 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:19:47 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:19:54 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:19:54 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:20:29 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:20:30 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:20:30 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:21:18 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:21:18 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:21:23 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:21:23 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:21:35 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:21:35 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:21:46 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-06-01 01:21:49 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:21:49 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:21:56 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:21:56 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:23:51 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:23:53 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:23:53 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:23:59 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:23:59 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:24:58 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:25:00 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:25:00 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:25:17 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:25:17 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:25:26 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:25:26 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:25:26 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:25:33 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:25:33 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:26:21 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:26:21 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:26:32 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:26:32 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:26:49 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:26:49 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:27:22 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:27:22 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:27:27 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:27:27 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:27:53 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:27:54 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:27:54 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:27:58 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:27:58 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:28:04 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:28:04 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:28:13 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:28:14 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:28:14 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:28:19 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:28:19 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:28:24 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:28:24 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:28:48 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:28:48 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:28:48 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:28:51 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:28:51 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:28:55 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:28:55 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:29:00 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:29:00 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:29:03 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:29:03 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:29:09 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:29:09 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:29:40 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:29:40 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:29:40 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:29:44 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:29:44 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:29:48 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:29:48 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:30:10 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:30:10 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:30:10 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:30:13 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:30:13 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:30:18 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:30:18 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:30:36 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:30:36 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:30:36 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:30:40 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:30:40 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:30:46 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:30:46 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:31:09 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:31:09 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:31:09 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:31:13 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:31:13 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:31:25 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:31:25 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:31:28 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:31:28 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:31:32 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:31:32 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:31:58 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:31:58 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:31:58 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:32:02 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:32:02 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:32:08 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:32:08 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:32:10 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:32:10 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:32:17 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:32:17 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:32:35 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:32:36 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:32:36 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:32:39 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:32:39 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:32:48 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:32:48 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:32:50 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:32:51 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:33:23 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:33:23 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:33:31 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:33:31 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:33:31 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:33:43 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:33:43 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:33:56 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:33:56 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:34:10 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:34:10 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:34:29 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:34:30 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:34:30 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:34:33 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:34:33 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:34:37 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:34:37 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:34:41 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:34:42 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:34:42 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:34:44 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:34:44 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:34:50 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:34:50 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:35:26 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:35:27 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:35:27 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:35:33 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:35:33 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:35:39 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:35:39 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:35:54 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:35:55 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:35:55 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:35:59 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:35:59 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:36:07 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:36:07 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:36:10 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:36:10 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:36:14 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:36:14 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:36:30 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:36:30 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:36:30 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:36:34 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:36:34 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:36:39 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:36:39 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:37:10 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:37:10 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:37:19 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:37:19 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:38:02 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:38:02 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:38:06 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:38:06 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:38:35 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:38:35 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:38:38 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:38:38 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:16 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:16 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:19 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:19 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:23 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:23 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:26 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:26 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:39 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:39 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:42 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:42 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:46 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:46 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:49 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:49 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:52 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:52 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:39:57 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:39:57 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:12 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:40:13 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:13 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:16 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:16 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:23 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:40:23 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:23 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:26 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:26 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:34 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:40:34 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:34 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:37 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:37 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:43 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:40:44 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:44 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:47 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:47 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:40:54 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-06-01 01:40:54 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:40:54 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:41:02 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:41:02 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:41:06 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:41:06 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:41:11 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:41:11 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:41:15 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:41:15 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:41:46 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:41:46 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:41:55 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:41:55 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:41:59 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:41:59 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:42:51 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:42:51 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:42:56 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:42:56 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:42:59 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:42:59 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:02 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:02 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:05 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:05 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:11 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:11 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:14 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:14 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:20 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:20 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:26 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:26 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:31 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:31 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:34 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:34 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:37 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:37 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:43 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:43 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:46 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:46 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:47 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:47 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:49 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:49 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:50 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:50 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:51 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:51 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:43:54 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:43:54 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:44:12 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:44:12 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:44:39 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:44:39 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:44:40 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:44:40 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:45:25 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 79
ERROR - 2023-06-01 01:45:25 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 80
ERROR - 2023-06-01 01:45:25 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 81
ERROR - 2023-06-01 01:48:20 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:48:20 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:54:45 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:54:45 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:57:03 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:57:03 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:57:29 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:57:29 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:58:04 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:58:04 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:58:17 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:58:17 --> 404 Page Not Found: /index
ERROR - 2023-06-01 01:58:54 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:58:54 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 01:59:04 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 01:59:04 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 02:04:29 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:04:32 --> 404 Page Not Found: 
ERROR - 2023-06-01 02:04:34 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:04:36 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:04:38 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:04:40 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:04:42 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:09:55 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 02:09:55 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 02:15:11 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:15:12 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:52:35 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:52:41 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:52:43 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:52:46 --> 404 Page Not Found: /index
ERROR - 2023-06-01 02:55:18 --> 404 Page Not Found: /index
ERROR - 2023-06-01 03:02:24 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 03:02:24 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 03:02:26 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 03:02:26 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 03:14:31 --> 404 Page Not Found: /index
ERROR - 2023-06-01 03:18:30 --> 404 Page Not Found: /index
ERROR - 2023-06-01 04:38:18 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:05:49 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:05:49 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:09:11 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:09:11 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:04 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:04 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:11 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:11 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:12 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:13 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:25 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:25 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:11:31 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:11:31 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:11:31 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:11:31 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:11:39 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:11:39 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:12:10 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:12:10 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:14:10 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:14:11 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:14:12 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:14:13 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:14:14 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:14:14 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:14:18 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:14:18 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:15:53 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:15:53 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:16:15 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:15 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:16:32 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:32 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:16:42 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:42 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:16:46 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:46 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:16:48 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:48 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:16:49 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:49 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:16:50 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:50 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:16:51 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:16:51 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:19:28 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:21:13 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:21:13 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:21:19 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:21:19 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:21:23 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:21:23 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:21:46 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:21:46 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:21:48 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:21:48 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:23:08 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:23:08 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:23:26 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:23:26 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:23:42 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:23:42 --> 404 Page Not Found: /index
ERROR - 2023-06-01 05:23:56 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:23:56 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:25:16 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:25:16 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:26:09 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:26:09 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:27:18 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:27:18 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:27:20 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:27:20 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:27:21 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:27:21 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 05:27:23 --> Could not find the language line "show_menu"
ERROR - 2023-06-01 05:27:23 --> Could not find the language line "hide_menu"
ERROR - 2023-06-01 06:53:40 --> 404 Page Not Found: /index
ERROR - 2023-06-01 06:53:40 --> 404 Page Not Found: /index
ERROR - 2023-06-01 07:51:22 --> 404 Page Not Found: /index
ERROR - 2023-06-01 07:51:31 --> 404 Page Not Found: /index
ERROR - 2023-06-01 07:56:38 --> 404 Page Not Found: /index
ERROR - 2023-06-01 09:04:29 --> 404 Page Not Found: /index
ERROR - 2023-06-01 12:58:55 --> 404 Page Not Found: /index
ERROR - 2023-06-01 14:16:22 --> 404 Page Not Found: /index
ERROR - 2023-06-01 14:16:22 --> 404 Page Not Found: /index
ERROR - 2023-06-01 14:16:38 --> 404 Page Not Found: /index
ERROR - 2023-06-01 14:16:38 --> 404 Page Not Found: /index
ERROR - 2023-06-01 14:46:05 --> 404 Page Not Found: /index
ERROR - 2023-06-01 14:46:05 --> 404 Page Not Found: /index
ERROR - 2023-06-01 17:01:45 --> 404 Page Not Found: /index
ERROR - 2023-06-01 17:11:10 --> 404 Page Not Found: /index
ERROR - 2023-06-01 17:11:10 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:55 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:55 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:55 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-06-01 18:51:55 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:55 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:55 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:56 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:56 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:56 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:56 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:56 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:57 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:57 --> 404 Page Not Found: /index
ERROR - 2023-06-01 18:51:57 --> 404 Page Not Found: /index
ERROR - 2023-06-01 19:31:54 --> 404 Page Not Found: /index
ERROR - 2023-06-01 19:31:55 --> 404 Page Not Found: /index
