<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-09 07:54:01 --> 404 Page Not Found: /index
ERROR - 2023-07-09 07:54:05 --> 404 Page Not Found: /index
ERROR - 2023-07-09 09:05:34 --> 404 Page Not Found: /index
ERROR - 2023-07-09 09:06:06 --> 404 Page Not Found: /index
ERROR - 2023-07-09 09:22:02 --> 404 Page Not Found: /index
ERROR - 2023-07-09 10:33:38 --> 404 Page Not Found: /index
ERROR - 2023-07-09 11:41:22 --> 404 Page Not Found: /index
ERROR - 2023-07-09 15:31:13 --> 404 Page Not Found: /index
ERROR - 2023-07-09 16:22:08 --> 404 Page Not Found: /index
ERROR - 2023-07-09 21:19:38 --> 404 Page Not Found: /index
ERROR - 2023-07-09 21:19:51 --> 404 Page Not Found: /index
ERROR - 2023-07-09 21:19:53 --> 404 Page Not Found: /index
ERROR - 2023-07-09 21:19:58 --> 404 Page Not Found: /index
ERROR - 2023-07-09 22:35:12 --> 404 Page Not Found: /index
