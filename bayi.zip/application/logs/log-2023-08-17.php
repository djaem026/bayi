<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-17 04:30:34 --> 404 Page Not Found: /index
ERROR - 2023-08-17 05:23:54 --> 404 Page Not Found: /index
ERROR - 2023-08-17 05:23:54 --> 404 Page Not Found: /index
ERROR - 2023-08-17 10:04:54 --> 404 Page Not Found: /index
ERROR - 2023-08-17 18:46:14 --> 404 Page Not Found: /index
ERROR - 2023-08-17 22:03:11 --> 404 Page Not Found: /index
