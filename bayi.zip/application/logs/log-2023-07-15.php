<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-15 05:20:43 --> 404 Page Not Found: /index
ERROR - 2023-07-15 15:51:15 --> 404 Page Not Found: /index
ERROR - 2023-07-15 20:33:58 --> 404 Page Not Found: /index
