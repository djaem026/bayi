<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-24 01:35:57 --> 404 Page Not Found: /index
ERROR - 2023-06-24 06:44:06 --> 404 Page Not Found: /index
ERROR - 2023-06-24 07:11:41 --> 404 Page Not Found: /index
ERROR - 2023-06-24 07:21:52 --> 404 Page Not Found: /index
ERROR - 2023-06-24 07:30:44 --> 404 Page Not Found: /index
ERROR - 2023-06-24 07:44:50 --> 404 Page Not Found: /index
ERROR - 2023-06-24 09:20:47 --> 404 Page Not Found: /index
ERROR - 2023-06-24 10:55:28 --> 404 Page Not Found: /index
ERROR - 2023-06-24 10:57:53 --> 404 Page Not Found: /index
ERROR - 2023-06-24 10:59:47 --> 404 Page Not Found: /index
ERROR - 2023-06-24 11:02:25 --> 404 Page Not Found: /index
