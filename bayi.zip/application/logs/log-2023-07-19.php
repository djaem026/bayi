<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-19 03:31:36 --> 404 Page Not Found: /index
ERROR - 2023-07-19 09:33:47 --> 404 Page Not Found: /index
ERROR - 2023-07-19 10:22:32 --> 404 Page Not Found: /index
ERROR - 2023-07-19 17:06:08 --> 404 Page Not Found: /index
ERROR - 2023-07-19 21:56:55 --> 404 Page Not Found: /index
