<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-05 09:44:02 --> 404 Page Not Found: /index
ERROR - 2023-08-05 09:44:03 --> 404 Page Not Found: /index
ERROR - 2023-08-05 09:44:04 --> 404 Page Not Found: /index
ERROR - 2023-08-05 16:47:32 --> 404 Page Not Found: /index
