<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-08 00:37:12 --> 404 Page Not Found: /index
ERROR - 2023-07-08 02:06:30 --> 404 Page Not Found: /index
ERROR - 2023-07-08 02:06:31 --> 404 Page Not Found: /index
ERROR - 2023-07-08 05:59:03 --> 404 Page Not Found: /index
ERROR - 2023-07-08 08:35:55 --> 404 Page Not Found: /index
ERROR - 2023-07-08 08:35:56 --> 404 Page Not Found: /index
ERROR - 2023-07-08 12:54:00 --> 404 Page Not Found: /index
ERROR - 2023-07-08 14:22:28 --> 404 Page Not Found: /index
ERROR - 2023-07-08 15:52:11 --> 404 Page Not Found: /index
ERROR - 2023-07-08 17:47:34 --> 404 Page Not Found: 
ERROR - 2023-07-08 17:54:56 --> 404 Page Not Found: /index
ERROR - 2023-07-08 20:12:35 --> 404 Page Not Found: /index
ERROR - 2023-07-08 21:29:46 --> 404 Page Not Found: /index
ERROR - 2023-07-08 21:46:26 --> 404 Page Not Found: /index
