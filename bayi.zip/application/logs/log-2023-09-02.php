<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-02 03:14:21 --> 404 Page Not Found: /index
ERROR - 2023-09-02 03:14:22 --> 404 Page Not Found: /index
ERROR - 2023-09-02 03:14:37 --> 404 Page Not Found: /index
ERROR - 2023-09-02 16:22:44 --> 404 Page Not Found: /index
ERROR - 2023-09-02 18:20:45 --> 404 Page Not Found: /index
ERROR - 2023-09-02 23:42:56 --> 404 Page Not Found: /index
