<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-01 02:27:32 --> 404 Page Not Found: /index
ERROR - 2023-07-01 02:27:33 --> 404 Page Not Found: /index
ERROR - 2023-07-01 03:28:40 --> 404 Page Not Found: /index
ERROR - 2023-07-01 03:28:40 --> 404 Page Not Found: /index
ERROR - 2023-07-01 03:28:50 --> 404 Page Not Found: /index
ERROR - 2023-07-01 10:48:24 --> 404 Page Not Found: /index
ERROR - 2023-07-01 14:54:55 --> 404 Page Not Found: /index
ERROR - 2023-07-01 21:27:35 --> 404 Page Not Found: /index
