<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-30 05:31:21 --> 404 Page Not Found: /index
ERROR - 2023-08-30 08:52:32 --> 404 Page Not Found: /index
ERROR - 2023-08-30 09:39:14 --> 404 Page Not Found: /index
ERROR - 2023-08-30 17:08:01 --> 404 Page Not Found: /index
