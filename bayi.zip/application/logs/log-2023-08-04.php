<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-04 00:36:00 --> 404 Page Not Found: /index
ERROR - 2023-08-04 01:46:03 --> 404 Page Not Found: /index
ERROR - 2023-08-04 04:27:01 --> 404 Page Not Found: /index
ERROR - 2023-08-04 05:20:02 --> 404 Page Not Found: /index
ERROR - 2023-08-04 07:51:14 --> 404 Page Not Found: /index
ERROR - 2023-08-04 08:53:08 --> 404 Page Not Found: /index
ERROR - 2023-08-04 11:49:00 --> 404 Page Not Found: /index
ERROR - 2023-08-04 12:17:44 --> 404 Page Not Found: /index
ERROR - 2023-08-04 12:17:44 --> 404 Page Not Found: /index
ERROR - 2023-08-04 12:17:45 --> 404 Page Not Found: /index
ERROR - 2023-08-04 12:17:46 --> 404 Page Not Found: /index
ERROR - 2023-08-04 12:39:03 --> 404 Page Not Found: /index
