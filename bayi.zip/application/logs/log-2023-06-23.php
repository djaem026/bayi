<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-23 10:56:35 --> 404 Page Not Found: /index
ERROR - 2023-06-23 11:23:44 --> 404 Page Not Found: /index
ERROR - 2023-06-23 11:33:49 --> 404 Page Not Found: /index
ERROR - 2023-06-23 11:42:53 --> 404 Page Not Found: /index
ERROR - 2023-06-23 11:57:15 --> 404 Page Not Found: /index
ERROR - 2023-06-23 15:35:35 --> 404 Page Not Found: /index
ERROR - 2023-06-23 19:14:25 --> 404 Page Not Found: /index
ERROR - 2023-06-23 19:14:25 --> 404 Page Not Found: /index
