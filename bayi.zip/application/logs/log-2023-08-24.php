<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-24 00:03:14 --> 404 Page Not Found: /index
ERROR - 2023-08-24 00:43:51 --> 404 Page Not Found: /index
ERROR - 2023-08-24 02:25:20 --> 404 Page Not Found: /index
ERROR - 2023-08-24 13:54:18 --> 404 Page Not Found: /index
ERROR - 2023-08-24 21:18:30 --> 404 Page Not Found: /index
ERROR - 2023-08-24 22:39:43 --> 404 Page Not Found: /index
