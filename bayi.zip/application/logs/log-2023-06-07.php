<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-07 06:32:17 --> 404 Page Not Found: /index
ERROR - 2023-06-07 06:32:17 --> 404 Page Not Found: /index
ERROR - 2023-06-07 14:50:11 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:45:07 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:45:07 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:02 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:02 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:03 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:03 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:05 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:08 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:09 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:09 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:10 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:11 --> 404 Page Not Found: /index
ERROR - 2023-06-07 15:49:13 --> 404 Page Not Found: /index
ERROR - 2023-06-07 19:30:11 --> 404 Page Not Found: /index
