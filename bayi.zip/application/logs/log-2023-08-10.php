<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-10 16:21:25 --> 404 Page Not Found: /index
ERROR - 2023-08-10 16:21:26 --> 404 Page Not Found: /index
ERROR - 2023-08-10 16:21:41 --> 404 Page Not Found: /index
ERROR - 2023-08-10 16:47:02 --> 404 Page Not Found: /index
ERROR - 2023-08-10 19:22:09 --> 404 Page Not Found: /index
