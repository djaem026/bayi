<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-27 04:43:17 --> 404 Page Not Found: /index
ERROR - 2023-06-27 04:43:25 --> 404 Page Not Found: /index
ERROR - 2023-06-27 04:50:11 --> 404 Page Not Found: /index
ERROR - 2023-06-27 13:24:55 --> 404 Page Not Found: /index
ERROR - 2023-06-27 14:11:20 --> 404 Page Not Found: /index
ERROR - 2023-06-27 14:11:20 --> 404 Page Not Found: /index
ERROR - 2023-06-27 14:39:39 --> 404 Page Not Found: /index
ERROR - 2023-06-27 14:39:51 --> 404 Page Not Found: /index
ERROR - 2023-06-27 14:44:23 --> 404 Page Not Found: /index
ERROR - 2023-06-27 15:16:46 --> 404 Page Not Found: /index
ERROR - 2023-06-27 15:31:04 --> 404 Page Not Found: /index
ERROR - 2023-06-27 15:35:43 --> 404 Page Not Found: /index
ERROR - 2023-06-27 21:26:48 --> 404 Page Not Found: /index
ERROR - 2023-06-27 21:26:49 --> 404 Page Not Found: /index
ERROR - 2023-06-27 21:30:07 --> 404 Page Not Found: /index
ERROR - 2023-06-27 21:30:18 --> 404 Page Not Found: /index
