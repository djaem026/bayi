<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-13 01:38:59 --> 404 Page Not Found: /index
ERROR - 2023-07-13 03:36:26 --> 404 Page Not Found: 
ERROR - 2023-07-13 05:08:43 --> 404 Page Not Found: 
ERROR - 2023-07-13 08:10:58 --> 404 Page Not Found: /index
ERROR - 2023-07-13 09:51:44 --> 404 Page Not Found: /index
ERROR - 2023-07-13 10:02:07 --> 404 Page Not Found: /index
ERROR - 2023-07-13 11:30:28 --> 404 Page Not Found: /index
ERROR - 2023-07-13 16:49:46 --> 404 Page Not Found: /index
ERROR - 2023-07-13 17:49:55 --> 404 Page Not Found: /index
ERROR - 2023-07-13 20:55:49 --> 404 Page Not Found: /index
ERROR - 2023-07-13 20:57:56 --> 404 Page Not Found: /index
