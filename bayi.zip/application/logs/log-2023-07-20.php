<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-20 00:46:28 --> 404 Page Not Found: /index
ERROR - 2023-07-20 04:05:19 --> 404 Page Not Found: /index
ERROR - 2023-07-20 06:39:48 --> 404 Page Not Found: /index
ERROR - 2023-07-20 06:49:04 --> 404 Page Not Found: /index
ERROR - 2023-07-20 18:31:06 --> 404 Page Not Found: /index
ERROR - 2023-07-20 18:31:06 --> 404 Page Not Found: /index
ERROR - 2023-07-20 21:14:28 --> 404 Page Not Found: /index
ERROR - 2023-07-20 21:36:01 --> 404 Page Not Found: /index
ERROR - 2023-07-20 22:44:03 --> 404 Page Not Found: /index
ERROR - 2023-07-20 23:03:04 --> 404 Page Not Found: /index
ERROR - 2023-07-20 23:03:04 --> 404 Page Not Found: /index
