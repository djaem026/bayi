<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-14 01:06:50 --> 404 Page Not Found: /index
ERROR - 2023-07-14 03:33:13 --> 404 Page Not Found: /index
ERROR - 2023-07-14 04:15:41 --> 404 Page Not Found: /index
ERROR - 2023-07-14 05:44:32 --> 404 Page Not Found: /index
ERROR - 2023-07-14 06:48:23 --> 404 Page Not Found: /index
ERROR - 2023-07-14 15:09:15 --> 404 Page Not Found: /index
ERROR - 2023-07-14 19:12:31 --> 404 Page Not Found: /index
ERROR - 2023-07-14 22:07:03 --> 404 Page Not Found: /index
ERROR - 2023-07-14 22:39:07 --> 404 Page Not Found: /index
