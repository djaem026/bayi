<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-19 02:36:30 --> 404 Page Not Found: /index
ERROR - 2023-08-19 08:45:55 --> 404 Page Not Found: /index
ERROR - 2023-08-19 09:52:42 --> 404 Page Not Found: /index
ERROR - 2023-08-19 09:53:08 --> 404 Page Not Found: /index
ERROR - 2023-08-19 10:56:53 --> 404 Page Not Found: /index
ERROR - 2023-08-19 10:57:14 --> 404 Page Not Found: /index
