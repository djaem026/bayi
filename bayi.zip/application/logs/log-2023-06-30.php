<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-30 00:50:11 --> 404 Page Not Found: /index
ERROR - 2023-06-30 02:10:11 --> 404 Page Not Found: /index
ERROR - 2023-06-30 02:13:05 --> 404 Page Not Found: /index
ERROR - 2023-06-30 02:13:05 --> 404 Page Not Found: /index
ERROR - 2023-06-30 08:04:18 --> 404 Page Not Found: /index
ERROR - 2023-06-30 14:33:36 --> 404 Page Not Found: /index
ERROR - 2023-06-30 14:33:36 --> 404 Page Not Found: /index
ERROR - 2023-06-30 22:01:12 --> 404 Page Not Found: /index
ERROR - 2023-06-30 22:01:25 --> 404 Page Not Found: /index
ERROR - 2023-06-30 22:01:26 --> 404 Page Not Found: /index
ERROR - 2023-06-30 22:01:27 --> 404 Page Not Found: /index
ERROR - 2023-06-30 22:01:56 --> 404 Page Not Found: /index
ERROR - 2023-06-30 22:01:56 --> 404 Page Not Found: /index
