<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-11 08:45:47 --> 404 Page Not Found: /index
ERROR - 2023-06-11 12:56:34 --> 404 Page Not Found: /index
ERROR - 2023-06-11 16:44:17 --> 404 Page Not Found: /index
ERROR - 2023-06-11 18:47:47 --> 404 Page Not Found: /index
ERROR - 2023-06-11 18:58:57 --> 404 Page Not Found: /index
ERROR - 2023-06-11 23:04:17 --> 404 Page Not Found: /index
ERROR - 2023-06-11 23:04:17 --> 404 Page Not Found: /index
