<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-04 00:11:22 --> 404 Page Not Found: /index
ERROR - 2023-06-04 00:11:23 --> 404 Page Not Found: /index
ERROR - 2023-06-04 01:28:45 --> 404 Page Not Found: /index
ERROR - 2023-06-04 01:28:46 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2023-06-04 02:18:12 --> 404 Page Not Found: /index
ERROR - 2023-06-04 04:08:40 --> 404 Page Not Found: /index
ERROR - 2023-06-04 05:35:02 --> 404 Page Not Found: /index
ERROR - 2023-06-04 05:35:02 --> 404 Page Not Found: /index
ERROR - 2023-06-04 10:47:45 --> 404 Page Not Found: /index
ERROR - 2023-06-04 10:47:45 --> 404 Page Not Found: /index
ERROR - 2023-06-04 10:48:51 --> 404 Page Not Found: /index
ERROR - 2023-06-04 10:48:51 --> 404 Page Not Found: /index
ERROR - 2023-06-04 11:52:14 --> 404 Page Not Found: /index
ERROR - 2023-06-04 17:40:33 --> 404 Page Not Found: /index
ERROR - 2023-06-04 18:43:39 --> 404 Page Not Found: /index
