<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-13 13:37:03 --> 404 Page Not Found: /index
ERROR - 2023-06-13 13:37:12 --> 404 Page Not Found: /index
ERROR - 2023-06-13 13:37:20 --> 404 Page Not Found: /index
ERROR - 2023-06-13 14:15:18 --> 404 Page Not Found: /index
ERROR - 2023-06-13 14:15:18 --> 404 Page Not Found: /index
ERROR - 2023-06-13 14:15:28 --> 404 Page Not Found: /index
ERROR - 2023-06-13 14:15:28 --> 404 Page Not Found: /index
ERROR - 2023-06-13 17:11:19 --> 404 Page Not Found: /index
ERROR - 2023-06-13 17:11:31 --> 404 Page Not Found: 
