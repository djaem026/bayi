<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-01 01:14:22 --> 404 Page Not Found: /index
ERROR - 2023-09-01 05:50:05 --> 404 Page Not Found: /index
ERROR - 2023-09-01 12:55:51 --> 404 Page Not Found: /index
ERROR - 2023-09-01 14:31:42 --> 404 Page Not Found: /index
ERROR - 2023-09-01 19:00:41 --> 404 Page Not Found: /index
ERROR - 2023-09-01 19:00:43 --> 404 Page Not Found: /index
ERROR - 2023-09-01 19:00:44 --> 404 Page Not Found: /index
