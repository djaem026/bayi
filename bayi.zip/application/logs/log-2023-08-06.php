<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-06 05:59:06 --> 404 Page Not Found: /index
ERROR - 2023-08-06 11:43:34 --> 404 Page Not Found: /index
ERROR - 2023-08-06 11:43:34 --> 404 Page Not Found: /index
ERROR - 2023-08-06 17:28:57 --> 404 Page Not Found: /index
ERROR - 2023-08-06 19:48:23 --> 404 Page Not Found: /index
ERROR - 2023-08-06 19:48:29 --> 404 Page Not Found: /index
ERROR - 2023-08-06 19:48:31 --> 404 Page Not Found: /index
