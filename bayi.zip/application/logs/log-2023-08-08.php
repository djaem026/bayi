<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-08 22:11:01 --> 404 Page Not Found: /index
