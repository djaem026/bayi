<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-23 17:38:25 --> 404 Page Not Found: /index
