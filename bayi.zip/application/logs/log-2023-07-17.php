<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-17 01:28:11 --> 404 Page Not Found: /index
ERROR - 2023-07-17 05:47:30 --> 404 Page Not Found: /index
ERROR - 2023-07-17 05:47:30 --> 404 Page Not Found: /index
ERROR - 2023-07-17 06:33:23 --> 404 Page Not Found: /index
ERROR - 2023-07-17 06:46:43 --> 404 Page Not Found: /index
ERROR - 2023-07-17 06:46:43 --> 404 Page Not Found: /index
ERROR - 2023-07-17 06:46:44 --> 404 Page Not Found: /index
ERROR - 2023-07-17 06:46:44 --> 404 Page Not Found: /index
ERROR - 2023-07-17 16:42:19 --> 404 Page Not Found: /index
ERROR - 2023-07-17 20:42:28 --> 404 Page Not Found: /index
ERROR - 2023-07-17 20:46:58 --> 404 Page Not Found: /index
