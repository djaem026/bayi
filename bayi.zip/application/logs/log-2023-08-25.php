<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-25 10:08:53 --> 404 Page Not Found: /index
ERROR - 2023-08-25 10:10:58 --> 404 Page Not Found: /index
ERROR - 2023-08-25 10:58:35 --> 404 Page Not Found: /index
ERROR - 2023-08-25 13:27:48 --> 404 Page Not Found: /index
ERROR - 2023-08-25 19:10:49 --> 404 Page Not Found: /index
