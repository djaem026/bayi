<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-12 06:02:42 --> 404 Page Not Found: /index
ERROR - 2023-08-12 06:02:43 --> 404 Page Not Found: /index
ERROR - 2023-08-12 06:02:44 --> 404 Page Not Found: /index
ERROR - 2023-08-12 07:12:56 --> 404 Page Not Found: /index
ERROR - 2023-08-12 21:21:46 --> 404 Page Not Found: /index
