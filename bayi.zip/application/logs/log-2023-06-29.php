<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-29 00:35:33 --> 404 Page Not Found: /index
ERROR - 2023-06-29 00:35:33 --> 404 Page Not Found: /index
ERROR - 2023-06-29 07:30:44 --> 404 Page Not Found: /index
ERROR - 2023-06-29 07:30:44 --> 404 Page Not Found: /index
ERROR - 2023-06-29 07:30:45 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2023-06-29 07:30:46 --> 404 Page Not Found: /index
ERROR - 2023-06-29 09:31:47 --> 404 Page Not Found: /index
ERROR - 2023-06-29 13:39:57 --> 404 Page Not Found: /index
