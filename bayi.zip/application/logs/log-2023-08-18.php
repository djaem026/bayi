<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-18 19:04:43 --> 404 Page Not Found: /index
