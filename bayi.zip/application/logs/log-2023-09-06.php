<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-06 03:54:23 --> 404 Page Not Found: /index
ERROR - 2023-09-06 03:54:25 --> 404 Page Not Found: /index
ERROR - 2023-09-06 03:54:27 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2023-09-06 03:54:28 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:01:53 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:01:53 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:01:57 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:01:58 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:01:58 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:02:04 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:02:04 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:02:09 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:02:09 --> 404 Page Not Found: /index
ERROR - 2023-09-06 13:02:09 --> 404 Page Not Found: /index
ERROR - 2023-09-06 18:10:10 --> 404 Page Not Found: /index
ERROR - 2023-09-06 20:11:17 --> 404 Page Not Found: /index
