<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-11 17:56:53 --> 404 Page Not Found: /index
ERROR - 2023-08-11 18:47:42 --> 404 Page Not Found: /index
