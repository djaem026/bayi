<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-06 01:11:22 --> 404 Page Not Found: /index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-06 01:11:22 --> 404 Page Not Found: /index
ERROR - 2023-07-06 09:29:44 --> 404 Page Not Found: /index
ERROR - 2023-07-06 11:44:58 --> 404 Page Not Found: /index
ERROR - 2023-07-06 16:16:21 --> 404 Page Not Found: /index
ERROR - 2023-07-06 17:06:18 --> 404 Page Not Found: /index
ERROR - 2023-07-06 19:59:28 --> 404 Page Not Found: /index
ERROR - 2023-07-06 23:36:11 --> 404 Page Not Found: /index
