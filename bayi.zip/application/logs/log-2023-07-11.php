<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-11 05:56:04 --> 404 Page Not Found: /index
ERROR - 2023-07-11 11:14:01 --> 404 Page Not Found: /index
ERROR - 2023-07-11 11:14:13 --> 404 Page Not Found: /index
ERROR - 2023-07-11 11:14:14 --> 404 Page Not Found: /index
ERROR - 2023-07-11 11:14:18 --> 404 Page Not Found: /index
ERROR - 2023-07-11 11:14:30 --> 404 Page Not Found: /index
ERROR - 2023-07-11 11:14:49 --> 404 Page Not Found: 
ERROR - 2023-07-11 11:14:59 --> 404 Page Not Found: /index
ERROR - 2023-07-11 18:17:21 --> 404 Page Not Found: /index
