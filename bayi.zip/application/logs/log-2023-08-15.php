<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 04:37:18 --> 404 Page Not Found: /index
ERROR - 2023-08-15 17:06:53 --> 404 Page Not Found: /index
ERROR - 2023-08-15 22:07:30 --> 404 Page Not Found: /index
ERROR - 2023-08-15 22:07:31 --> 404 Page Not Found: /index
ERROR - 2023-08-15 22:07:31 --> 404 Page Not Found: /index
