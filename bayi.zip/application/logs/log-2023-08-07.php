<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-07 02:44:01 --> 404 Page Not Found: /index
ERROR - 2023-08-07 10:13:43 --> 404 Page Not Found: /index
ERROR - 2023-08-07 15:25:00 --> 404 Page Not Found: /index
ERROR - 2023-08-07 16:50:35 --> 404 Page Not Found: /index
ERROR - 2023-08-07 19:14:08 --> 404 Page Not Found: /index
ERROR - 2023-08-07 21:56:44 --> 404 Page Not Found: /index
