<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-22 03:08:16 --> 404 Page Not Found: /index
ERROR - 2023-07-22 03:08:16 --> 404 Page Not Found: /index
ERROR - 2023-07-22 03:46:26 --> 404 Page Not Found: /index
ERROR - 2023-07-22 04:54:28 --> 404 Page Not Found: /index
ERROR - 2023-07-22 05:25:35 --> 404 Page Not Found: /index
ERROR - 2023-07-22 11:14:46 --> 404 Page Not Found: /index
ERROR - 2023-07-22 16:27:48 --> 404 Page Not Found: /index
ERROR - 2023-07-22 16:27:50 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2023-07-22 20:16:17 --> 404 Page Not Found: /index
