<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-27 07:22:09 --> 404 Page Not Found: /index
ERROR - 2023-08-27 09:19:56 --> 404 Page Not Found: /index
ERROR - 2023-08-27 09:21:29 --> 404 Page Not Found: /index
ERROR - 2023-08-27 10:12:56 --> 404 Page Not Found: /index
ERROR - 2023-08-27 13:42:16 --> 404 Page Not Found: /index
ERROR - 2023-08-27 13:42:18 --> 404 Page Not Found: /index
ERROR - 2023-08-27 18:02:50 --> 404 Page Not Found: /index
