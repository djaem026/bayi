<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-22 05:18:27 --> 404 Page Not Found: /index
ERROR - 2023-06-22 18:37:46 --> 404 Page Not Found: /index
ERROR - 2023-06-22 19:05:17 --> 404 Page Not Found: /index
ERROR - 2023-06-22 19:15:16 --> 404 Page Not Found: /index
ERROR - 2023-06-22 19:24:06 --> 404 Page Not Found: /index
ERROR - 2023-06-22 19:24:18 --> 404 Page Not Found: /index
ERROR - 2023-06-22 19:38:07 --> 404 Page Not Found: /index
