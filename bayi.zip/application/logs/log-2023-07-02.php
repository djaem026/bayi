<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-02 08:14:59 --> 404 Page Not Found: /index
ERROR - 2023-07-02 08:51:58 --> 404 Page Not Found: /index
ERROR - 2023-07-02 08:51:58 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:00 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:15 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:16 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:20 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:23 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:29 --> 404 Page Not Found: 
ERROR - 2023-07-02 13:37:42 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:57 --> 404 Page Not Found: /index
ERROR - 2023-07-02 13:37:57 --> 404 Page Not Found: /index
