<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-16 01:48:14 --> 404 Page Not Found: /index
ERROR - 2023-08-16 05:07:06 --> 404 Page Not Found: /index
