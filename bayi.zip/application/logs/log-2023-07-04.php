<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-04 01:38:56 --> 404 Page Not Found: /index
ERROR - 2023-07-04 03:16:55 --> 404 Page Not Found: /index
ERROR - 2023-07-04 04:40:38 --> 404 Page Not Found: /index
ERROR - 2023-07-04 12:26:56 --> 404 Page Not Found: /index
