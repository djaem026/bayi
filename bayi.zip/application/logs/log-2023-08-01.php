<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-01 00:16:01 --> 404 Page Not Found: /index
ERROR - 2023-08-01 00:16:14 --> 404 Page Not Found: /index
ERROR - 2023-08-01 00:16:15 --> 404 Page Not Found: /index
ERROR - 2023-08-01 00:16:16 --> 404 Page Not Found: /index
ERROR - 2023-08-01 00:16:36 --> 404 Page Not Found: /index
ERROR - 2023-08-01 00:16:36 --> 404 Page Not Found: /index
ERROR - 2023-08-01 16:36:28 --> 404 Page Not Found: /index
