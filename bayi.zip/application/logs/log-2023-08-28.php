<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-28 02:14:18 --> 404 Page Not Found: /index
ERROR - 2023-08-28 02:14:29 --> 404 Page Not Found: /index
ERROR - 2023-08-28 02:14:29 --> 404 Page Not Found: /index
ERROR - 2023-08-28 02:54:04 --> 404 Page Not Found: /index
ERROR - 2023-08-28 09:46:15 --> 404 Page Not Found: /index
ERROR - 2023-08-28 09:46:34 --> 404 Page Not Found: /index
ERROR - 2023-08-28 11:45:30 --> 404 Page Not Found: /index
