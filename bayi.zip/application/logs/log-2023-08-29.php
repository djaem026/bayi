<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-29 02:05:04 --> 404 Page Not Found: /index
ERROR - 2023-08-29 02:05:10 --> 404 Page Not Found: /index
ERROR - 2023-08-29 06:01:01 --> 404 Page Not Found: /index
ERROR - 2023-08-29 08:52:48 --> 404 Page Not Found: /index
ERROR - 2023-08-29 09:43:58 --> 404 Page Not Found: /index
ERROR - 2023-08-29 18:08:39 --> 404 Page Not Found: /index
