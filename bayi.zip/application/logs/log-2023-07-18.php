<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-18 00:49:28 --> 404 Page Not Found: /index
ERROR - 2023-07-18 03:41:08 --> 404 Page Not Found: /index
ERROR - 2023-07-18 03:43:16 --> 404 Page Not Found: /index
ERROR - 2023-07-18 06:01:38 --> 404 Page Not Found: /index
ERROR - 2023-07-18 07:02:21 --> 404 Page Not Found: /index
ERROR - 2023-07-18 09:46:06 --> 404 Page Not Found: /index
ERROR - 2023-07-18 09:46:06 --> 404 Page Not Found: /index
ERROR - 2023-07-18 09:46:08 --> 404 Page Not Found: /index
ERROR - 2023-07-18 09:46:09 --> 404 Page Not Found: /index
ERROR - 2023-07-18 13:15:59 --> 404 Page Not Found: /index
ERROR - 2023-07-18 13:27:10 --> 404 Page Not Found: /index
ERROR - 2023-07-18 13:27:28 --> 404 Page Not Found: /index
ERROR - 2023-07-18 13:59:25 --> 404 Page Not Found: /index
ERROR - 2023-07-18 15:33:09 --> 404 Page Not Found: /index
ERROR - 2023-07-18 15:42:30 --> 404 Page Not Found: /index
ERROR - 2023-07-18 18:10:34 --> 404 Page Not Found: /index
ERROR - 2023-07-18 22:03:18 --> 404 Page Not Found: /index
ERROR - 2023-07-18 22:52:09 --> 404 Page Not Found: /index
ERROR - 2023-07-18 23:37:13 --> 404 Page Not Found: /index
