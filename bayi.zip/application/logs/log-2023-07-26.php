<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-26 01:25:56 --> 404 Page Not Found: /index
ERROR - 2023-07-26 16:48:15 --> 404 Page Not Found: /index
