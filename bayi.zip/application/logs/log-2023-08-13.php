<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-13 01:15:56 --> 404 Page Not Found: /index
ERROR - 2023-08-13 04:31:54 --> 404 Page Not Found: /index
ERROR - 2023-08-13 10:51:13 --> 404 Page Not Found: /index
ERROR - 2023-08-13 15:37:10 --> 404 Page Not Found: /index
ERROR - 2023-08-13 15:37:10 --> 404 Page Not Found: /index
ERROR - 2023-08-13 15:37:11 --> 404 Page Not Found: /index
ERROR - 2023-08-13 15:37:11 --> 404 Page Not Found: /index
ERROR - 2023-08-13 18:13:56 --> 404 Page Not Found: /index
ERROR - 2023-08-13 18:26:13 --> 404 Page Not Found: /index
ERROR - 2023-08-13 18:26:22 --> 404 Page Not Found: /index
ERROR - 2023-08-13 18:26:23 --> 404 Page Not Found: /index
ERROR - 2023-08-13 20:02:25 --> 404 Page Not Found: /index
