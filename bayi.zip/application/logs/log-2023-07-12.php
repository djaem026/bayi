<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-12 03:01:44 --> 404 Page Not Found: /index
ERROR - 2023-07-12 14:50:07 --> 404 Page Not Found: /index
ERROR - 2023-07-12 22:30:54 --> 404 Page Not Found: /index
