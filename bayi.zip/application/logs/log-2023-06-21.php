<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-21 15:22:51 --> 404 Page Not Found: /index
ERROR - 2023-06-21 15:50:30 --> 404 Page Not Found: /index
ERROR - 2023-06-21 16:00:35 --> 404 Page Not Found: /index
ERROR - 2023-06-21 16:09:34 --> 404 Page Not Found: /index
ERROR - 2023-06-21 16:24:08 --> 404 Page Not Found: /index
ERROR - 2023-06-21 19:22:55 --> 404 Page Not Found: /index
ERROR - 2023-06-21 19:22:55 --> 404 Page Not Found: /index
ERROR - 2023-06-21 19:23:05 --> 404 Page Not Found: /index
ERROR - 2023-06-21 23:01:38 --> 404 Page Not Found: /index
ERROR - 2023-06-21 23:01:38 --> 404 Page Not Found: /index
ERROR - 2023-06-21 23:30:11 --> 404 Page Not Found: /index
