<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-26 09:50:01 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:50:01 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:50:05 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:50:05 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:55:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:55:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:55:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:55:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:55:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:55:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:55:26 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:55:26 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:56:54 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:56:54 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:02 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:02 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:11 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:11 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:24 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:24 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:57:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:57:50 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:57:50 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:58:01 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:58:01 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:58:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:58:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:58:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:58:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:58:33 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:58:33 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:59:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:59:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:59:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 09:59:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 09:59:31 --> 404 Page Not Found: /index
ERROR - 2023-05-26 09:59:31 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:00:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:00:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:00:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:00:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:00:38 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:00:38 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:01:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:01:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:01:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:01:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:01:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:01:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:01:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:01:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:02:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:02:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:02:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:02:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:02:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:02:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:02:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:02:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:03:06 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:03:06 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:03:14 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:03:15 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:03:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:03:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:03:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:03:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:03:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:03:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:03:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:03:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:03:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:03:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:04:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:04:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:04:00 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:04:00 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:04:00 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:04:00 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:04:00 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:04:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:04:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:04:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:04:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:05:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:05:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:05:46 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:05:46 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:05:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:05:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:06:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:06:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:07:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:07:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:07:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:07:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:07:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:07:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:07:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:07:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:07:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:07:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:08:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:08:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:08:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:08:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:09:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:09:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:09:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:09:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:09:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:09:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:09:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:09:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:09:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:09:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:10:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:10:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:10:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:10:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:11:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:11:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:11:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:11:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:11:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:11:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:11:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:11:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:11:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:11:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:12:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:12:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:12:48 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:12:48 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:13:07 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:13:07 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:13:11 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:13:11 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:13:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:13:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:13:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:13:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:13:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:13:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:14:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:14:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:14:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:14:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:15:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:15:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:15:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:15:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:16:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:16:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:16:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:16:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:16:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:16:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:16:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:16:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:16:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:16:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:16:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:16:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:18:02 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:02 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:20 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:20 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:25 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:27 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:28 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:28 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:29 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:29 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:29 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:29 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:30 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:30 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:30 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:30 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:30 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:30 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:31 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:31 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:31 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:31 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:31 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:31 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:32 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:32 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:32 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:32 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:33 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:33 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:33 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:34 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:34 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:36 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:38 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:38 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\controllers\Home.php 130
ERROR - 2023-05-26 10:18:39 --> 404 Page Not Found: 
ERROR - 2023-05-26 10:18:43 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:18:43 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:19:03 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:19:03 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:19:41 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\bayi\system\libraries\Email.php 1903
ERROR - 2023-05-26 10:20:54 --> Could not find the language line "user_order_history"
ERROR - 2023-05-26 10:21:10 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:21:10 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:21:37 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:21:37 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:21:58 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:21:58 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:22:05 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:22:05 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:22:47 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:22:47 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:23:13 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:23:13 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:23:23 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:23:23 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:23:50 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:23:50 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:25:02 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:25:49 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:25:49 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:26:12 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:26:12 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:26:46 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:26:46 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:26:51 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:26:51 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:27:18 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:27:19 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:27:29 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:27:29 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:27:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:27:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:27:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:27:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:28:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:28:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:28:30 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:28:30 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:28:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:28:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:28:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:28:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:28:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:28:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:28:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:28:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:28:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:28:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:28:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:28:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:29:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-26 10:29:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-26 10:31:25 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:31:26 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:31:32 --> 404 Page Not Found: /index
ERROR - 2023-05-26 10:31:32 --> 404 Page Not Found: /index
