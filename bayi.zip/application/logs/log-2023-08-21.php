<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-21 00:04:20 --> 404 Page Not Found: /index
ERROR - 2023-08-21 00:04:26 --> 404 Page Not Found: /index
ERROR - 2023-08-21 00:04:26 --> 404 Page Not Found: /index
ERROR - 2023-08-21 01:35:38 --> 404 Page Not Found: /index
ERROR - 2023-08-21 09:46:07 --> 404 Page Not Found: /index
ERROR - 2023-08-21 10:15:29 --> 404 Page Not Found: /index
ERROR - 2023-08-21 12:48:58 --> 404 Page Not Found: /index
ERROR - 2023-08-21 13:00:34 --> 404 Page Not Found: /index
ERROR - 2023-08-21 13:15:48 --> 404 Page Not Found: /index
ERROR - 2023-08-21 15:09:13 --> 404 Page Not Found: /index
ERROR - 2023-08-21 16:55:23 --> 404 Page Not Found: /index
ERROR - 2023-08-21 16:56:13 --> 404 Page Not Found: /index
ERROR - 2023-08-21 22:33:15 --> 404 Page Not Found: /index
ERROR - 2023-08-21 22:50:01 --> 404 Page Not Found: /index
