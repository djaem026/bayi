<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-31 01:29:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 02:11:03 --> 404 Page Not Found: /index
ERROR - 2023-05-31 02:11:03 --> 404 Page Not Found: /index
ERROR - 2023-05-31 03:28:47 --> 404 Page Not Found: /index
ERROR - 2023-05-31 03:28:47 --> 404 Page Not Found: /index
ERROR - 2023-05-31 03:47:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 03:47:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 03:47:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 04:35:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 04:35:49 --> 404 Page Not Found: /index
ERROR - 2023-05-31 04:37:27 --> 404 Page Not Found: /index
ERROR - 2023-05-31 04:37:27 --> 404 Page Not Found: /index
ERROR - 2023-05-31 04:39:31 --> 404 Page Not Found: /index
ERROR - 2023-05-31 04:39:31 --> 404 Page Not Found: /index
ERROR - 2023-05-31 04:40:19 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:04:44 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:08:50 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:08:51 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:40:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:59:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:59:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:59:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 05:59:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:18:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:18:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:18:19 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:31:02 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:31:02 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:31:46 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:31:46 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:32:56 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:32:56 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:33:59 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:33:59 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:52:27 --> 404 Page Not Found: /index
ERROR - 2023-05-31 06:52:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 06:52:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 06:52:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 06:52:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 06:52:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 06:52:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 07:01:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:28 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:28 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:29 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:29 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:29 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:31 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:01:31 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:02:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 07:02:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 07:02:41 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:02:41 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:02:55 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:02:55 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:03:29 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:03:51 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:59:47 --> 404 Page Not Found: /index
ERROR - 2023-05-31 07:59:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 08:49:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 08:49:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 08:49:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 08:49:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 08:52:36 --> 404 Page Not Found: /index
ERROR - 2023-05-31 08:52:37 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:09:22 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:09:22 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:13:59 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:13:59 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:14:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 09:14:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 09:14:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 09:14:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 09:15:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:15:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:16:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:16:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 09:18:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 09:18:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 10:18:00 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:00 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:03 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:03 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:04 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:05 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:05 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:18:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:26:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 10:26:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 10:26:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 10:26:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 10:27:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 10:27:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 10:29:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 10:29:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 10:31:34 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:31:34 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:32:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:32:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:52:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 10:52:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 10:53:55 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:53:55 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:54:06 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:54:06 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:55:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 10:55:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 11:21:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 11:21:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 11:45:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 11:45:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 11:45:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 11:45:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:02:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:02:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:09:31 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:09:31 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:10:52 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:10:52 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:15:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:15:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:15:28 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:25:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:25:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:26:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:26:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:27:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:27:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:28:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:28:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:28:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:28:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:30:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:30:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:31:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:31:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:33:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:33:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:33:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:33:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:34:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:34:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:37:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:37:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:38:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:38:18 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:38:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:38:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:38:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:38:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:39:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:40:35 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2023-05-31 12:40:43 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2023-05-31 12:40:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:40:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:49:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:49:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:50:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:50:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:50:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:50:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:53:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:53:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:54:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:54:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:56:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:56:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:58:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:58:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:58:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 12:58:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 12:59:06 --> 404 Page Not Found: /index
ERROR - 2023-05-31 12:59:06 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:00:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:00:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:00:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:00:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:01:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:01:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:01:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:01:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:02:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:02:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:08:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:08:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:08:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:08:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:08:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:08:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:08:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:08:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:12:33 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:12:33 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:23:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:23:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:23:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:23:54 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2023-05-31 13:23:56 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2023-05-31 13:23:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:23:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:24:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:24:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:26:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:26:14 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:27:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:27:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:27:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:27:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:30:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:30:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:30:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:30:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:30:50 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:30:50 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:38:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:38:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:40:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:40:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:40:38 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:40:38 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:43:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:43:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:44:09 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:44:09 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:44:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:44:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:44:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:44:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:45:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:45:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:45:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:45:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:45:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:45:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:46:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:46:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:46:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:46:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:46:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:46:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:46:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:46:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:47:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:47:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:47:14 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:47:14 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:47:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:47:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:48:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:48:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:48:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:48:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:48:39 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:48:39 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:49:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:49:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:50:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:50:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:52:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:52:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:53:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:53:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:53:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:53:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:54:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:54:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:54:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:54:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:54:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:54:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:55:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:55:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:55:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:55:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:56:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:56:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:56:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:56:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:57:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:57:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:57:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:57:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:57:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:57:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:58:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 13:58:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 13:58:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 13:58:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:00:02 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:00:02 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:00:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:00:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:00:20 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:00:20 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:01:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:01:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:01:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:01:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:01:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:01:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:02:05 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:02:05 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:04:35 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:04:35 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:04:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:04:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:05:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:05:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:05:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:05:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:05:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:05:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:05:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:05:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:05:58 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:05:58 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:06:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:06:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:06:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:06:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:07:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:07:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:07:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:07:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:07:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:07:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:08:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:08:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:08:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:08:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:08:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:08:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:09:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:09:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:09:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:09:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:09:37 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:09:37 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:09:57 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:09:57 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:10:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:10:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:10:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:10:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:10:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:10:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:10:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:10:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:10:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:10:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:10:29 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:10:29 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:10:36 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-31 14:10:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:10:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:10:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:10:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:10:43 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:10:43 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:11:43 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:11:43 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:14:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:14:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:15:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:15:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:15:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:15:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:15:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:15:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:15:33 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:15:38 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:15:43 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:15:47 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:15:52 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:16:08 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:16:14 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:17:14 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:17:18 --> Severity: Notice --> Undefined index: name /home/u299472748/domains/bayi.space/public_html/application/modules/admin/controllers/ecommerce/ShopCategories.php 80
ERROR - 2023-05-31 14:17:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:17:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:17:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:17:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:18:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:18:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:18:06 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-31 14:18:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:18:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:18:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:18:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:18:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:18:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:18:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:18:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:18:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:18:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:18:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:18:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:18:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:18:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:19:27 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:19:27 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:19:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:19:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:19:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:19:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:19:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:19:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:22:42 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:23:57 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:24:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:24:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:25:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:25:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:26:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:26:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:26:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:26:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:26:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:26:26 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:26:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:26:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:26:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 14:26:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 14:56:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:56:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:57:53 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:10 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:16 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:17 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:40 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:55 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:58:55 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:05 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:14 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:16 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:16 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:24 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:24 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:36 --> 404 Page Not Found: /index
ERROR - 2023-05-31 14:59:36 --> 404 Page Not Found: /index
ERROR - 2023-05-31 15:00:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 15:00:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 15:00:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 15:00:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 15:05:04 --> 404 Page Not Found: /index
ERROR - 2023-05-31 15:05:04 --> 404 Page Not Found: /index
ERROR - 2023-05-31 15:05:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 15:05:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 15:05:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 15:05:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 15:05:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 15:05:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 15:05:34 --> 404 Page Not Found: /index
ERROR - 2023-05-31 15:05:34 --> 404 Page Not Found: /index
ERROR - 2023-05-31 15:05:42 --> 404 Page Not Found: /index
ERROR - 2023-05-31 15:05:42 --> 404 Page Not Found: /index
ERROR - 2023-05-31 15:05:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 15:05:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 15:05:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 15:05:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:26:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:26:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:26:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:26:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:26:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:26:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:27:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:27:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:27:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:27:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:28:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:28:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:28:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:28:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:28:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:28:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:28:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:28:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:30:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:30:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:30:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:30:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:30:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 16:30:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 16:39:03 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:39:21 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:41:55 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:42:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:09 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:10 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:11 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-05-31 16:45:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:11 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:12 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 16:45:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:53:04 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:53:37 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:54:42 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:54:42 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:54:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:54:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:56:22 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:56:22 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:56:34 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:56:56 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:57:05 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:57:05 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:57:24 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:57:24 --> 404 Page Not Found: /index
ERROR - 2023-05-31 18:59:51 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:32:28 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 79
ERROR - 2023-05-31 19:32:28 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 80
ERROR - 2023-05-31 19:32:28 --> Severity: Notice --> Undefined index: logged_user /home/u299472748/domains/bayi.space/public_html/application/controllers/Users.php 81
ERROR - 2023-05-31 19:32:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:32:48 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:32:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:32:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:33:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:33:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:33:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:33:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:33:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:33:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:33:39 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:33:39 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:34:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:34:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:34:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:34:13 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:34:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:34:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:46:10 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:46:10 --> 404 Page Not Found: /index
ERROR - 2023-05-31 19:48:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:48:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:48:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:48:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:48:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:48:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:48:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:48:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:48:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:48:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:48:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:48:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:50:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:50:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:58:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:58:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 19:58:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 19:58:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:05:18 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:05:18 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:05:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:05:45 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:06:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:06:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:07:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:07:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:07:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:07:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:07:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:07:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:08:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:08:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:09:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:09:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:10:08 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:10:08 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:10:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:10:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:15:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:15:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:15:44 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:15:44 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:16:09 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:16:09 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:17:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:17:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:18:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:18:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:18:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:18:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:19:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:19:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:19:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:19:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:19:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:19:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:22:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:22:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:22:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:22:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:22:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:22:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:22:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:22:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:23:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:23:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:23:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:23:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:25:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:25:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:25:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:25:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:25:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:25:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:25:39 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-31 20:25:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:25:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:25:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:25:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:26:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:26:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:29:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:29:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:29:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:29:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:29:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:29:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:29:52 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:29:52 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:30:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:30:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:31:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:31:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:31:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:31:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:31:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:31:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:31:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:31:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:33:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:33:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:33:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:33:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:33:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:33:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:34:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:34:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:35:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:35:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:35:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:35:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:35:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:35:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:35:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:35:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:36:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:36:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:37:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:37:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:37:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:37:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:37:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:37:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:38:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:38:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:38:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:38:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:38:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:38:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:38:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:38:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:39:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:39:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:39:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:39:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:40:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:40:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:41:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:41:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:41:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:41:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:42:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:42:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:42:18 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:42:18 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:43:19 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:43:19 --> 404 Page Not Found: /index
ERROR - 2023-05-31 20:43:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:43:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:45:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:45:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:46:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:46:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:46:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:46:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:46:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:46:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:46:37 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-31 20:46:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:46:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:46:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:46:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:46:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:46:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:47:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:47:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:47:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:47:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:47:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:47:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:48:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:48:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:49:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:49:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:49:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:49:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:49:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:49:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:50:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:50:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:50:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:50:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:51:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:51:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:51:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:51:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:51:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:51:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:51:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:51:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:51:51 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-31 20:51:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:51:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:51:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:51:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:52:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:52:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:52:14 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-31 20:52:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:52:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:52:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:52:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:52:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:52:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:53:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:53:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:53:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:53:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:53:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:53:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:54:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:54:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:54:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:54:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:55:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:55:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:55:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:55:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:56:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:56:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:56:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:56:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:56:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:56:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:57:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:57:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:57:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:57:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:57:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:57:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:58:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:58:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:58:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:58:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:58:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:58:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 20:58:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 20:58:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 21:03:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 21:03:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 21:03:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 21:03:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 21:04:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:04:07 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:09:39 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:09:39 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:10:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:10:30 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:11:06 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:11:06 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:11:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:11:25 --> 404 Page Not Found: /index
ERROR - 2023-05-31 21:32:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 21:32:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 21:32:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 21:32:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 21:40:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 21:40:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-31 22:05:04 --> 404 Page Not Found: /index
ERROR - 2023-05-31 23:05:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 23:05:01 --> 404 Page Not Found: /index
ERROR - 2023-05-31 23:05:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-31 23:05:07 --> Could not find the language line "hide_menu"
