<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-25 17:01:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\bayi\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-05-25 17:01:51 --> Unable to connect to the database
ERROR - 2023-05-25 17:02:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:02:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:02:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:02:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:02:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:02:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:02:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:02:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:02:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:02:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:02:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:02:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:02:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:02:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:03:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:03:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:03:23 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:03:23 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:03:30 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:03:30 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:03:30 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:03:30 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:03:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:03:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:04:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:04:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:04:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:04:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:05:12 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:05:13 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:05:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:05:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:05:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:06:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:06:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:07:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:07:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:07:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:07:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:07:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:07:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:07:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:07:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:07:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:07:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:07:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:07:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:07:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:07:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:08:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:08:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:08:20 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:08:20 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:08:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:08:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:08:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:08:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:09:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:09:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:09:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:09:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:09:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:10:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:10:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:10:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:10:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:10:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:10:21 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-25 17:10:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:10:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:10:51 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:10:51 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:10:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:10:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:11:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:11:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:11:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:11:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:11:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:11:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:11:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:11:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:11:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:11:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:12:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:12:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:12:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:12:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:12:31 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:12:31 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:13:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:13:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:13:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:14:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:14:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:14:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:14:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:14:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:14:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:14:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:14:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:14:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:14:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:16 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:15:16 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:15:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:15:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:15:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:16:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:16:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:16:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:16:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:17:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:17:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:17:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:17:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:17:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:17:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:17:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:17:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:17:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:17:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:18:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:18:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:18:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:18:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:18:37 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:18:37 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:18:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:21:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:21:48 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-25 17:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\bayi\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-25 17:24:10 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-25 17:24:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:24:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:25:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:25:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:26:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:26:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:26:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:26:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:26:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:26:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-25 17:26:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-25 17:26:31 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:26:31 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:29:21 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-25 17:29:42 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-25 17:29:55 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:29:55 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:29:57 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:29:57 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:29:59 --> 404 Page Not Found: /index
ERROR - 2023-05-25 17:29:59 --> 404 Page Not Found: /index
