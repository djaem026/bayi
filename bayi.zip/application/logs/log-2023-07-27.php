<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-27 08:58:30 --> 404 Page Not Found: /index
ERROR - 2023-07-27 10:06:17 --> 404 Page Not Found: /index
ERROR - 2023-07-27 23:27:21 --> 404 Page Not Found: /index
