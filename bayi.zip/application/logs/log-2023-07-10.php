<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-10 03:19:56 --> 404 Page Not Found: /index
ERROR - 2023-07-10 04:08:01 --> 404 Page Not Found: /index
ERROR - 2023-07-10 05:02:18 --> 404 Page Not Found: /index
ERROR - 2023-07-10 10:33:37 --> 404 Page Not Found: /index
ERROR - 2023-07-10 11:57:12 --> 404 Page Not Found: /index
ERROR - 2023-07-10 15:51:30 --> 404 Page Not Found: /index
ERROR - 2023-07-10 22:37:01 --> 404 Page Not Found: /index
