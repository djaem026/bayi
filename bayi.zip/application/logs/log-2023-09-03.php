<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-03 05:20:51 --> 404 Page Not Found: /index
ERROR - 2023-09-03 05:36:45 --> 404 Page Not Found: /index
ERROR - 2023-09-03 06:20:12 --> 404 Page Not Found: /index
ERROR - 2023-09-03 11:52:08 --> 404 Page Not Found: /index
ERROR - 2023-09-03 16:46:54 --> 404 Page Not Found: /index
ERROR - 2023-09-03 17:43:57 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:00:18 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:06:58 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:07:12 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:07:13 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:07:14 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:07:34 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:07:34 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:22:21 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:58:44 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:58:55 --> 404 Page Not Found: /index
ERROR - 2023-09-03 18:58:56 --> 404 Page Not Found: /index
ERROR - 2023-09-03 22:03:23 --> 404 Page Not Found: /index
ERROR - 2023-09-03 23:31:23 --> 404 Page Not Found: /index
