<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-03 11:40:44 --> 404 Page Not Found: /index
ERROR - 2023-07-03 12:30:27 --> 404 Page Not Found: /index
