<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-23 04:39:48 --> 404 Page Not Found: /index
ERROR - 2023-07-23 11:19:18 --> 404 Page Not Found: /index
ERROR - 2023-07-23 13:40:02 --> 404 Page Not Found: /index
ERROR - 2023-07-23 21:41:55 --> 404 Page Not Found: /index
ERROR - 2023-07-23 21:42:03 --> 404 Page Not Found: /index
ERROR - 2023-07-23 21:42:06 --> 404 Page Not Found: /index
