<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-24 17:41:49 --> 404 Page Not Found: /index
